# A.py

def main():
    banner = r'''
     █████      ███████   ██   ██
    ██   ██          ██   ██   ██
    ███████     ███████   ███████
    ██   ██     ██        ██   ██
    ██   ██     ███████   ██   ██
    

     [ ASH ] - Welcome to BLACK DEMON
'''
    print(banner)

if __name__ == "__main__":
    main()
