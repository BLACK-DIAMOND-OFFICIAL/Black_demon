from utils.banner import show_banner
from utils.random_runner import run_random_script
import os
import subprocess

loaded_module = None

def is_valid_python_file(file_path):
    return file_path.endswith(".py") and os.path.isfile(file_path)

def process_command(cmd):
    global loaded_module
    tokens = cmd.split()
    if not tokens:
        return

    command = tokens[0].lower()

    if command in ["exit", "quit"]:
        print("[!] Exiting BDSAM...")
        exit(0)

    elif command == "help":
        print("""
Available commands:
  use <module.py>  - Select a Python module
  set <option>     - Set an option (not implemented yet)
  show <type>      - Show modules, options, etc.
  run              - Execute the selected module
  clear            - Clear the screen
  banner           - Run random script from utils/
  exit / quit      - Exit BDSAM
""")

    elif command == "clear":
        os.system("clear" if os.name == "posix" else "cls")

    elif command == "banner":
        run_random_script()

    elif command == "use":
        if len(tokens) < 2:
            print("[!] Usage: use <module.py>")
            return
        module = tokens[1]
        if not module.endswith(".py"):
            print("[!] Only Python (.py) modules are supported.")
            return
        if not os.path.isfile(module):
            print(f"[!] Module '{module}' not found.")
            return
        loaded_module = module
        print(f"[+] Module '{module}' loaded.")

    elif command == "run":
        if not loaded_module:
            print("[!] No module selected. Use 'use <module.py>' to select a module.")
            return
        if is_valid_python_file(loaded_module):
            print(f"[+] Running module: {loaded_module}")
            subprocess.run(["python3", loaded_module])
        else:
            print(f"[!] Invalid Python module: {loaded_module}")

    elif command == "set":
        print("[*] 'set' command not yet implemented.")

    elif command == "show":
        print("[*] 'show' command not yet implemented.")

    else:
        print(f"[!] Unknown command: {cmd}")

def main():
    show_banner()
    while True:
        try:
            cmd = input("BDSAM > ").strip()
            process_command(cmd)
        except KeyboardInterrupt:
            print("\n[!] Keyboard interrupt detected. Type 'exit' to quit.")
        except Exception as e:
            print(f"[!] Error: {e}")

if __name__ == "__main__":
    main()
