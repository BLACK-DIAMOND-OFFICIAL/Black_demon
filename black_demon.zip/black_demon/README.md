# Black Demon

**Black Demon** is a powerful and anonymous penetration testing framework developed by **Black Diamond**. It is designed for safe and stealthy operations using the Tor network and supports custom module creation and execution.

## Features

- **Full anonymity** through Tor integration.
- **Custom module support** in multiple languages (Python, Ruby, Bash, C, C++, Java).
- **Secure testing environment** for module execution.
- **Expandable** through external modules (sold separately).

## Requirements

- Python 3.10+
- Tor service installed and running
- Git
- Linux or Windows (Linux recommended)
- Root/admin privileges for certain actions

© 2025 Black Diamond
