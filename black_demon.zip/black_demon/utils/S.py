# utils/banner.py

def show_banner():
    banner = """
    



    """
    print(banner)
