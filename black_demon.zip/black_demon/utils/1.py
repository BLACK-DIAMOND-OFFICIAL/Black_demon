# utils/banner.py

def show_banner():
    banner = """
    =============================
      BLACK DEMON Framework
           [BDSAM Console]
    =============================
    """
    print(banner)
