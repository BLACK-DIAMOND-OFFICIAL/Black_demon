import random
import subprocess
import os

def run_random_script():
    files = ["A.py", "S.py", "D.py", "F.py", "G.py", "H.py", "J.py", "K.py", "L.py"]
    base_path = os.path.dirname(__file__)
    chosen = random.choice(files)
    script_path = os.path.join(base_path, chosen)

    if os.path.isfile(script_path):
        print(f"[+] Running random file: {chosen}")
        subprocess.run(["python3", script_path])
    else:
        print(f"[!] File not found: {script_path}")
